import socket;

name = "localhost"                                      # DNS lookup for the IP address
port = 15008                                            # Integer variable
cs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)   # Client socket
buf = 1024                                              # Buffer size                                                                    
addr = (name, port)                                     # Address                                     

f = open("image.jpg", "rb")                             # Opens the image                      

def rdt_send():                                         # function definition                                              
    print "sending 1024 bytes" 
    data = f.read(buf)                                  # Reads 1024 bytes of data                           
    cs.sendto(data, addr)                               # Sends data of size 1024 bytes 
                
for x in range(0,1500):                                 # Loop executes for 2000 times
    rdt_send()                                          # Function call                              
         
f.close()                                               # Closes file
cs.close()                                              # Closes socket
