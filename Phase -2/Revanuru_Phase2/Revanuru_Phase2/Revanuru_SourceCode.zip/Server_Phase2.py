import socket

name = "localhost"                                      # DNS lookup for the IP
port = 15008                                            # Interger variable
ss = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)   # Server socket
ss.bind((name, port))                                   # Binds port number to the socket

print "server started"
buf = 1024                                              # Buffer size = 1024                     
addr = (name, port)                                     # Address
f = open("newimage.jpg", "wb")                         # Opens newimage.jpg  

def rdt_recv():                                         # Function definition        
    data, addr = ss.recvfrom(buf)                       # Receives data of size 1024 bytes
    print "received 1024 bytes" 
    f.write(data)                                       # Writes the data to the image file
   
for x in range(0,1500):                                 # Loop executes for 2000 times
    rdt_recv()                                          # Function call                                  

f.close()                                               # File closes
print "file downloaded"
